from flask import Flask, request, jsonify
import requests

app = Flask(__name__)

@app.route('/api/skin')
def skin():
    nombre = request.args.get('nombre')
    if not nombre:
        return jsonify({'error':'Falta parametro nombre'}),400
    steam = round(5 + len(nombre)*0.3,2)
    dmarket = round(steam*0.9,2)
    data = {
        "nombre": nombre,
        "startrack": "StatTrak" in nombre,
        "precios":[
            {"sitio":"Steam","precio":steam,"url":f"https://steamcommunity.com/market/listings/730/{nombre.replace(' ','%20')}"},
            {"sitio":"DMarket","precio":dmarket,"url":f"https://dmarket.com/skin/{nombre.replace(' ','-')}"}
        ],
        "precio_minimo":{
            "sitio":"DMarket" if dmarket<steam else "Steam",
            "precio":min(steam,dmarket)
        }
    }
    return jsonify(data)

if __name__=='__main__':
    app.run(host='0.0.0.0', port=5000)
