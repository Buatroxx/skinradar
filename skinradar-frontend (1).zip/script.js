let currentCurrency = "USD";

document.addEventListener("DOMContentLoaded", () => {
  const searchInput = document.getElementById("searchInput");
  const currencySelector = document.getElementById("currencySelector");
  loadSearchHistory();
  searchInput.addEventListener("keypress", e => {
    if (e.key === "Enter") {
      let query = e.target.value.trim();
      if (query) {
        saveToHistory(query);
        showResults(query);
      }
    }
  });
  currencySelector.addEventListener("change", e => {
    currentCurrency = e.target.value;
    updatePricesDisplay();
  });
});

function saveToHistory(term) {
  let h = JSON.parse(localStorage.getItem("history")) || [];
  if (!h.includes(term)) {
    h.unshift(term);
    if (h.length > 10) h.pop();
    localStorage.setItem("history", JSON.stringify(h));
    loadSearchHistory();
  }
}

function loadSearchHistory() {
  const h = JSON.parse(localStorage.getItem("history")) || [];
  const cont = document.getElementById("history");
  cont.innerHTML = "";
  h.forEach(t => {
    let btn = document.createElement("button");
    btn.textContent = t;
    btn.onclick = () => showResults(t);
    cont.appendChild(btn);
  });
}

async function showResults(query) {
  const rd = document.getElementById("results");
  rd.innerHTML = "Buscando precios...";
  const isStar = document.getElementById("startrack").checked;
  const nombre = isStar ? `StatTrak ${query}` : query;
  try {
    let res = await fetch(`https://TU_BACKEND_URL/api/skin?nombre=${encodeURIComponent(nombre)}`);
    let data = await res.json();
    rd.innerHTML = "";
    let item = document.createElement("div");
    item.innerHTML = `
      <h2>${data.nombre}</h2>
      <ul>${data.precios.map(p=>`
        <li>${p.sitio}: <strong>${p.precio.toFixed(2)}</strong> <a href="${p.url}" target="_blank">Ver</a></li>`).join("")}
      </ul>
      <p>🔹 Precio más barato: ${data.precio_minimo.precio.toFixed(2)} (${data.precio_minimo.sitio})</p>
      <button onclick="addToFavorites('${data.nombre}')">⭐ Agregar a favoritos</button>
    `;
    rd.appendChild(item);
  } catch {
    rd.innerHTML = "Error al buscar precios.";
  }
}

function addToFavorites(item) {
  let f = JSON.parse(localStorage.getItem("favorites"))||[];
  if (!f.includes(item)) {
    f.push(item);
    localStorage.setItem("favorites", JSON.stringify(f));
    alert("Agregado a favoritos");
  }
}

function updatePricesDisplay() {
  const last = JSON.parse(localStorage.getItem("history"))?.[0];
  if (last) showResults(last);
}
